// Observações de pesquisa são separadas de regras habilitadas para cálculo.
// Nenhuma observação substitui revisão profissional ou ativa uma versão.
export const ITCMD_DATE = '2026-10-06';
export const FEDERAL_ITCMD = {
 title:'Lei Complementar 227/2026 — Livro II',
 url:'https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp227.htm',
 consultedOn:ITCMD_DATE,
 provisions:'Arts. 148, § 2º; 152 a 159; 182, III',
 effects:'O art. 182, III prevê efeitos desde a publicação para esses dispositivos. A aplicação de legislação estadual e eventual majoração exige conferência própria.',
 reviewStatus:'Pendente de validação jurídica e contábil',
 notes:[
  'O art. 148, § 2º trata separadamente sucessores ou donatários por ente competente.',
  'Os arts. 152 a 154 tratam da base de cálculo; o valor informado pelo visitante não é avaliação fiscal nem homologação.',
  'O art. 155 trata da agregação de doações sucessivas. O período depende da legislação estadual ou distrital.',
  'O art. 156 prevê progressividade por faixas e distingue a data da doação da abertura da sucessão.',
  'Para imóveis no Brasil, o art. 158 indica a UF da localização. Para móveis e participações, o art. 159 distingue domicílio do doador e do falecido, conforme a operação.'
 ]
};
export const itcmdResearch = {
  "AC": {
    "donation": "Faixas de 2%, 4%, 6% e 8%: até R$ 25 mil; excedente até R$ 100 mil; excedente até R$ 200 mil; acima de R$ 200 mil.",
    "inheritance": "Faixas de 4%, 5%, 6% e 7%; regra de 8% para colaterais.",
    "notes": "Art. 29: 4% sobre o excedente de R$ 50 mil até R$ 1,5 milhão; 5% no excedente até R$ 2,5 milhões; 6% no excedente até R$ 3,5 milhões; 7% acima disso. Art. 4º prevê isenções do espólio e do único imóvel. Monte-mor, parentesco, alterações posteriores e compatibilidade com a LC 227/2026 exigem conferência; não tratar como simples faixa por beneficiário.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://sefaz.ac.gov.br/2021/?page_id=17032",
        "provision": "Índice oficial de legislação",
        "consultedOn": "2026-10-06"
      },
      {
        "url": "https://sefaz.ac.gov.br/2021/?p=5118",
        "provision": "LC 373/2020, arts. 4º, 26, 29 e 30",
        "consultedOn": "2026-10-06"
      },
      {
        "url": "https://sefaz.ac.gov.br/2021/?p=23486",
        "provision": "Portaria SEFAZ 105/2026, avaliação de imóveis rurais",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "AL": {
    "donation": "2%, conforme FAQ oficial.",
    "inheritance": "4% para óbitos desde 01/04/2017, conforme FAQ oficial.",
    "notes": "FAQ também distingue óbitos anteriores a 01/04/2017. Lei consolidada, alterações posteriores, isenções e aplicação em 2026 ainda pendentes; não presumir que a FAQ esgote a legislação.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://www.sefaz.al.gov.br/itcd/itcd-faq",
        "provision": "FAQ: Qual a alíquota do ITCD?",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "ES": {
    "donation": "4% no art. 12 do texto consultado.",
    "inheritance": "4% no art. 12 do texto consultado.",
    "notes": "Lei 10.011/2013 disponibilizada como atualizada pela SEFAZ: isenções no art. 7º. Conferir alterações, marco temporal e aplicação da progressividade federal em 2026 antes de calcular.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://sefaz.es.gov.br/media/Receita%20Estadual/Legislacao/Lei%2010.011%20atualizada.pdf",
        "provision": "Lei 10.011/2013, arts. 7º e 12",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "GO": {
    "donation": "Faixas progressivas de 2%, 4%, 6% e 8%.",
    "inheritance": "Mesmas faixas de 2%, 4%, 6% e 8%, conforme FAQ.",
    "notes": "FAQ 43: até R$ 25 mil, 2%; de R$ 25 mil até R$ 200 mil, 4% e dedução de R$ 500; até R$ 600 mil, 6% e dedução de R$ 4.500; acima, 8% e dedução de R$ 16.500. Regime informado desde 01/01/2016. FAQ 40 cita isenção de doações até R$ 20 mil, com agregação em dois anos; FAQ 45 trata agregação em 12 meses para alíquotas. Conferir legislação e condições completas.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://goias.gov.br/economia/perguntas-e-respostas-11/",
        "provision": "FAQ ITCD, questões 39 a 45",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "MG": {
    "donation": "5% desde 28/03/2008 no texto consultado.",
    "inheritance": "5% desde 28/03/2008 no texto consultado.",
    "notes": "Lei consolidada apresenta redações históricas de 2%, 3%, 4% e 6%, que não devem ser confundidas com o art. 10 atual. Isenções, UFEMG anual, descontos, doações sucessivas em três anos civis e compatibilidade com a LC 227/2026 exigem revisão.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://www.fazenda.mg.gov.br/empresas/legislacao_tributaria/leis/l14941_2003.html",
        "provision": "Lei 14.941/2003, arts. 3º, 7º, 10 e 11; nota de efeitos (11)",
        "consultedOn": "2026-10-06"
      },
      {
        "url": "https://www.fazenda.mg.gov.br/empresas/legislacao_tributaria/decretos/d43981_2005.html",
        "provision": "Decreto 43.981/2005, texto consolidado",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "PE": {
    "donation": "Desde 01/01/2026: isenção até R$ 80 mil; faixas de 2%, 4%, 6% e 8%.",
    "inheritance": "Desde 01/01/2026: isenção até R$ 80 mil; faixas de 2%, 4%, 6% e 8%.",
    "notes": "Faixas: até R$ 350 mil, 2% e dedução de R$ 1.600; até R$ 550 mil, 4% e dedução de R$ 8.600; até R$ 750 mil, 6% e dedução de R$ 19.600; acima, 8% e dedução de R$ 34.600. Há isenção residencial condicionada até R$ 270 mil, outras isenções, agregação anual para doações e desconto por pagamento. Valores sujeitos à atualização prevista em lei; não aplicar a datas fora de 2026 sem nova conferência.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://www.sefaz.pe.gov.br/Legislacao/Tributaria/Documents/Legislacao/Leis_Complementares_Estadual/2025/LCE563_2025.htm",
        "provision": "LC 563/2025, arts. 20 e 27 e anexos 6 e 7; Lei 13.974/2009, Anexo 2, arts. 8º e 11, e Anexo 3",
        "consultedOn": "2026-10-06"
      },
      {
        "url": "https://www.sefaz.pe.gov.br/Servicos/ICD/Paginas/Perguntas-e-Respostas.aspx",
        "provision": "FAQ ICD, tabela para fatos desde 01/01/2026",
        "consultedOn": "2026-10-06"
      }
    ]
  },
  "SP": {
    "donation": "4% para doação em dinheiro acima do limite indicado pela FAQ.",
    "inheritance": "Ainda sem percentual confirmado nesta pesquisa.",
    "notes": "FAQ consultada cita limite de 2.500 UFESPs para doações em dinheiro e soma anual entre mesmo doador e donatário. O valor da UFESP de 2026, demais bens, causa mortis e legislação consolidada ainda precisam ser conferidos. Não generalizar esta resposta para toda transmissão.",
    "consultedOn": "2026-10-06",
    "status": "observed-review-pending",
    "sources": [
      {
        "url": "https://portal.fazenda.sp.gov.br/servicos/itcmd/Paginas/perguntas-frequentes.aspx",
        "provision": "FAQ: A doação feita em dinheiro está sujeita ao ITCMD? Decreto 46.655/2002, art. 6º, I, b",
        "consultedOn": "2026-10-06"
      }
    ]
  }
};
export const itcmdStates = [
 ['AC','Acre','https://sefaz.ac.gov.br/'],
 ['AL','Alagoas','https://www.sefaz.al.gov.br/'],
 ['AP','Amapá','https://www.sefaz.ap.gov.br/'],
 ['AM','Amazonas','https://www.sefaz.am.gov.br/'],
 ['BA','Bahia','https://www.sefaz.ba.gov.br/'],
 ['CE','Ceará','https://www.sefaz.ce.gov.br/'],
 ['DF','Distrito Federal','https://www.receita.fazenda.df.gov.br/'],
 ['ES','Espírito Santo','https://sefaz.es.gov.br/'],
 ['GO','Goiás','https://goias.gov.br/economia/'],
 ['MA','Maranhão','https://portal.sefaz.ma.gov.br/'],
 ['MT','Mato Grosso','https://www.sefaz.mt.gov.br/'],
 ['MS','Mato Grosso do Sul','https://www.sefaz.ms.gov.br/'],
 ['MG','Minas Gerais','https://www.fazenda.mg.gov.br/'],
 ['PA','Pará','https://www.sefa.pa.gov.br/'],
 ['PB','Paraíba','https://www.sefaz.pb.gov.br/'],
 ['PR','Paraná','https://www.fazenda.pr.gov.br/'],
 ['PE','Pernambuco','https://www.sefaz.pe.gov.br/'],
 ['PI','Piauí','https://www.sefaz.pi.gov.br/'],
 ['RJ','Rio de Janeiro','https://portal.fazenda.rj.gov.br/'],
 ['RN','Rio Grande do Norte','https://www.sefaz.rn.gov.br/'],
 ['RS','Rio Grande do Sul','https://www.receita.fazenda.rs.gov.br/'],
 ['RO','Rondônia','https://www.sefin.ro.gov.br/'],
 ['RR','Roraima','https://www.sefaz.rr.gov.br/'],
 ['SC','Santa Catarina','https://www.sef.sc.gov.br/'],
 ['SP','São Paulo','https://portal.fazenda.sp.gov.br/servicos/itcmd/'],
 ['SE','Sergipe','https://www.sefaz.se.gov.br/'],
 ['TO','Tocantins','https://www.to.gov.br/sefaz/']
].map(([uf,name,portal])=>{
 const observation=itcmdResearch[uf]||null;
 const reachable=['AM','DF','MS','PR','RR','SC'].includes(uf);
 const blocker=observation?'Percentuais observados em fonte oficial; regras completas, vigência aplicável e revisão profissional ainda pendentes.':reachable?'Portal consultado, mas legislação ou página específica ainda não confirmou percentuais. Há destinos adicionais pendentes de acesso.':'Falha de acesso ao conteúdo oficial: rede, indisponibilidade ou bloqueio do portal. Percentuais ainda não confirmados.';
 return {uf,name,portal,status:observation?'observed-review-pending':reachable?'research-pending':'access-failed',attemptedOn:ITCMD_DATE,consultedOn:observation?.consultedOn||null,sourceVerified:false,professionalReview:null,versions:[],observation,blocker};
});
export const instrumentScenarios = {
 testamento:{operations:['inheritance'],assets:['property','movable','shares'],explanation:'Simulação da transmissão após o falecimento, não da elaboração do testamento.'},
 doacao:{operations:['donation'],assets:['property','movable','shares'],explanation:'Doação de propriedade plena. Reserva ou extinção de usufruto depende de regras específicas e não é calculada nesta versão.'},
 holding:{operations:['donation','inheritance'],assets:['shares'],explanation:'Somente transmissão de participações da sociedade. Constituir a holding ou integralizar imóveis não equivale a uma doação de quotas; ITBI, IR e outros custos exigem análise separada.'},
 participacoes:{operations:['donation','inheritance'],assets:['shares'],explanation:'Transmissão de participações, com valor informado para discussão. A avaliação das quotas exige metodologia própria; não use automaticamente seu valor nominal.'},
 inventario:{operations:['inheritance'],assets:['property','movable','shares'],explanation:'Simulação da transmissão causa mortis, considerando a data da abertura da sucessão. Não estima emolumentos, taxas ou honorários.'}
};
export const SIMULATION_NOTICE = 'Simulação exclusivamente informativa para preparação de consulta. Não é guia de pagamento, avaliação fiscal ou confirmação de imposto devido. Conteúdo e regras pendentes de validação profissional.';
